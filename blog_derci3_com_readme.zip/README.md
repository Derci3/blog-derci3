# Meu Blog Pessoal

Este é um blog simples criado com HTML e CSS, hospedado no GitHub Pages.

## Sobre

Este projeto é um blog estático básico onde compartilho ideias e histórias pessoais. Foi criado para aprender como fazer sites e publicar online gratuitamente usando GitHub Pages.

## Como usar

1. Clone este repositório ou baixe os arquivos.
2. Abra o arquivo `index.html` no navegador para ver o blog localmente.
3. Para publicar no GitHub Pages:
   - Crie um repositório no GitHub.
   - Envie os arquivos (especialmente o `index.html`).
   - Ative o GitHub Pages nas configurações do repositório.

## Licença

Este projeto está sem licença definida no momento.

---

Criado por Derci3.
